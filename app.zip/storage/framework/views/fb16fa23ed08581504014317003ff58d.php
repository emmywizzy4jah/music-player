

<?php $__env->startSection('content'); ?>
            <!----Upload and Share Wrapper Start---->
            <div class="ms_upload_wrapper marger_top60">
                <div class="ms_upload_box">
                    <h2>Upload & Share Your Music With The World</h2>
                    <img src="<?php echo e(asset('images/svg/upload.svg')); ?>" alt="">
                    <div class="ms_upload_btn">
                        <button type="button" id="openmusupload" class="ms_btn">Choose Music file</button>
						<input type="file" id="musicfile" style="display:none" />
                    </div>
                    <span> or </span>
                    <p>Drag And Drop Music Files</p>
                </div>
                <div class=" marger_top60">
                    <div class="ms_upload_box">
                        <div class="ms_heading">
                            <h1>Track Information</h1>
                        </div>
                        <div class="ms_pro_form">
							<form id="uploadmusicform" action="<?php echo e(route('user.uploadmusic.submit')); ?>">
								<div class="form-group">
									<label>Track Name *</label>
									<input type="text" placeholder="Dream Your Moments" class="form-control" id="track" required />
								</div>
								<div class="form-group">
									<label>Select Artiste</label>
									<select class="form-control" id="artiste" required>
										<option value=""> -- Select -- </option>
									<?php $__currentLoopData = $artistes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artiste): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($artiste->id); ?>"><?php echo e($artiste->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
								<div class="form-group">
									<label>Select Album</label>
									<select class="form-control" id="album" required>
										<option value=""> -- Select -- </option>
									<?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($album->id); ?>"><?php echo e($album->title); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
								<div class="form-group">
									<label>Select Genre</label>
									<select class="form-control" id="genre" required>
										<option value=""> -- Select -- </option>
									<?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($genre->id); ?>"><?php echo e($genre->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
								<div class="form-group">
									<label>Duration*</label>
									<input type="text" placeholder="Duration of the song" class="form-control" id="duration" required />
								</div>
								<div class="form-group">
									<label>Photo*</label>
									<input type="file" placeholder="Music Photo" class="form-control" id="musicphoto" required />
								</div>
								<div class="pro-form-btn text-center marger_top15">
									<div class="ms_upload_btn">
										<button type="submit" id="upmussubmitbtn" class="save_btn">Upload Now</button>
										<button type="reset" class="save_btn">cancel</button>
									</div>
								</div>
							</form>
                        </div>
                    </div>
                </div>
            </div>
            <!----Main div close---->
<script>				

	  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\musicstream\resources\views/upload.blade.php ENDPATH**/ ?>