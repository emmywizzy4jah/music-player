<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Carbon\Carbon;
use App\Models\User;
use App\Models\Album;
use App\Models\Artiste;
use App\Models\Genre;
use App\Models\Song;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Validator;

use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Hash;

use Illuminate\Support\Facades\File;
use Intervention\Image\Facades\Image;
use Intervention\Image\ImageManager;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;

class DashboardController extends Controller
{
    //
    public function blocked()
    {
        $title ='User Barred';
        //$settings = Setting::where('id', 1)->first();
        return view('user.blocked',compact('title'));
    }

    public function dashboard()
    {
        $users = User::get();
        return view('dashboard',compact('users'));
    }
    
    public function profile()
    {
        return view('profile');
    }

    public function uploadmusic()
    {
        $artistes = Artiste::get();
        $genres = Genre::get();
        $albums =Album::get();
        return view('upload',compact('artistes','genres','albums'));   
    }

    public function musicsubmit(Request $request)
    {

        if($request->hasfile('musicfile'))
        {
            $file = $request->file('musicfile');
            $music = $file->hashName();
            $extension = $file->extension();

            $whitelist = array('mp3');
                
            if(in_array($extension, $whitelist)){
                $path = $file->store('music', 'upload');
            }else{
                return response()->json(['status' => 500, 'error' => 'Unaccepted music file Uploaded']);
            }
        }
        
        if($request->hasfile('musicphoto'))
        {
            $file = $request->file('musicphoto');
            $photo = $file->hashName();
            $extension = $file->extension();

            $whitelist = array('jpeg','jpg','png');
                
            if(in_array($extension, $whitelist)){
                $path = $file->store('photo', 'upload');
            }else{
                return response()->json(['status' => 500, 'error' => 'Unaccepted Image Uploaded']);
            }
        }

      $song = new Song;
      $song->photo = $photo;
      $song->path = $music;
      $song->title = $request->track;
      $song->duration = $request->duration;
      $song->artiste_id = $request->artiste;
      $song->album_id = $request->album;
      $song->genre_id = $request->genre;
      $result = $song->save();
      if($result){

      }else{

      }
    }
    
    public function updateprofile(Request $request)
    {
        $profile = Auth::user();
        $profile->name = $request->name;
        $profile->email = strtolower($request->email);
        $profile->username = $request->username;
        $profile->sex = $request->sex;
        $profile->phone = $request->phone;
        $profile->dob = date("Y-m-d", strtotime($request->dob));
        //$profile->country_id = $request->country;
        //$profile->city = $request->city;
        //$profile->zipcode = $request->zipcode;
        //$profile->address = $request->address;
        $result = $profile->save();
        if($result){
            // event(new PasswordUpdated(Auth::user()));
            return response()->json(['status' => 200, 'success' => 'Profile Information updated successfully!']);
        }else{
         return response()->json(['status' => 500, 'error' => 'Profile Information not updated successfully!']);
        }
    }

    //Update Password
    public function updatepass(Request $request)
    {
        $request->validate([
          'current_password' => 'required',
          'password' => 'required|string|min:6|confirmed',
          'password_confirmation' => 'required',
        ]);
  
        $user = Auth::user();
        if(!Hash::check($request->current_password, $user->password)){
          return response()->json(['status' => 500, 'error' => 'Current password does not match!']);
        }
        $user->password = bcrypt($request->password);
        $result = $user->save();
        if($result){
            return response()->json(['status' => 200, 'success' => 'Password updated successfully!']);
        }else{
         return response()->json(['status' => 500, 'error' => 'Password not updated successfully!']);
        }
    }
    
    public function avatar(Request $request)
    {
        $request->validate([
            'photo' => 'sometimes|nullable|mimes:jpeg,png,jpg|max:5120',
        ]);

        $current_photo = Auth::user();
		$photo = NULL;
        $current_image = $current_photo->photo;
        $pathImage = public_path('/user/images/avatars/');
		 if ($request->hasFile('photo')) {
            $file = $request->file('photo');
                $images = Image::make($file)->insert($file)->resize(400,400);
					$photo = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
                    $images->save($pathImage . $photo);
                    $imageName = $pathImage . $photo;
				
            }
            if ($request->hasFile('photo') && $current_photo->photo !=="") {
                if (file_exists($pathImage. $current_photo->photo)) {
                    File::delete($pathImage. $current_photo->photo);
                }else{
                    $current_image = $current_photo->photo;
                }
            }

            $profile = Auth::user();
         if($request->file('photo') ==""){
             $profile->photo = $current_image;
         }else{
             $profile->photo = $photo; 
         }
            $result = $profile->save();
            if($result){
                return response()->json(['success' => 'Account updated successfully!'],200);
            }else{
             return response()->json(['error' => 'Account not updated successfully!'],400);
            }
      }
}
