<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
//use App\Models\Setting;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Carbon\Carbon;

use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Hash;

use Illuminate\Support\Facades\File;
//use Intervention\Image\Facades\Image;
use Intervention\Image\ImageManager;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\View;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;

use App\Mail\WelcomeEmail;
use App\Mail\ResetLink;
use App\Mail\EmailVerify;

class AuthController extends Controller
{
    //
    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required',
            'password' => 'required',
        ]);
        //check authentication 
        if($request->email !=""){
            if(Auth::attempt(['email' => $request->email, 'password' => $request->password, 'active' => 1])){
                return response()->json(['status' => 200, "success"=> "Logged in successfully!", "user" => Auth::user()]);
            } else {
                //logout
                return response()->json(['status' => 500, "error"=>"Invalid Login Details"]);
            }
        }elseif($request->username !=""){
            if(Auth::attempt(['username' => $request->username, 'password' => $request->password, 'active' => 1])){
                return response()->json(['status' => 200, "success"=> "Logged in successfully!", "user" => Auth::user()]);
            } else {
                //logout
                return response()->json(['status' => 500, "error"=>"Invalid Login Details"]);
            }
        }else{
            if(Auth::attempt(['phone' => $request->phone, 'password' => $request->password, 'active' => 1])){
                return response()->json(['status' => 200, "success"=> "Logged in successfully!", "user" => Auth::user()]);
            } else {
                //logout
                return response()->json(['status' => 500, "error"=>"Invalid Login Details", "user" => Auth::user()]);
            }
        }
    }

    public function register(Request $request)
    {
       // $terms = TermsPrivacy::first();
        //if($terms->useterms =='yes'){
            $request->validate([
                'name' => 'required|string|max:255',
                'username' => 'required|string|max:255|unique:users',
                'email' => 'required|string|email|max:255|unique:users',
                //'dob' => 'required',
                'password' => 'required|string|min:6',
                'cpassword' => 'required|same:password',
                //'agree' => 'required',
                //'g-recaptcha-response' => 'required|recaptcha',
            ]);
        // }else{
        //     $request->validate([
        //         'name' => 'required|string|max:255',
        //         'username' => 'required|string|max:255|unique:users',
        //         'email' => 'required|string|email|max:255|unique:users',
        //         //'dob' => 'required',
        //         'password' => 'required|string|min:6',
        //         'cpassword' => 'required|same:password',
        //         //'g-recaptcha-response' => 'required|recaptcha',
        //     ]);
        // }

       // $gs = Setting::first();

        $user = new User;
        //$user->uid = rand(1000000, 9999999);
        $user->name = $request->name;
        $user->email = strtolower($request->email);
        $user->username = $request->username;
        //$user->phone = $request->phone;
        $user->password = bcrypt($request->password);
        //$user->role = 'users';
        //$user->dob = date('Y-m-d', strtotime($request->dob));
       // $user->country_id = $request->country;
   // if($gs->enable_verification ==  "true"){
        //$user->verification_token = Str::random(40);
        $user->access = 1;
        $user->active = 1;
    // }else{ 
    //     $user->access = 1;
    //     $user->active = 1;
    // }
        $result = $user->save();


        if($result){
        // $gs = Setting::first();
        //     if($gs->enable_verification == "true"){
        //         Mail::to($user->email)->send(new EmailVerify($user));
        //     }else{
        //         Mail::to($user->email)->send(new WelcomeEmail($user));
        //     }
            return response()->json(['status' => 200, 'success' => 'Account created successfully!']);
        }else{
         return response()->json(['status' => 500, 'error' => 'Account not created successfully, something went wrong!']);
        }
    }

    public function showLinkRequestForm()
    {
        $title = 'Forgot Password';
        //$settings = Setting::where('id', 1)->first();
        return view('forgot',compact('title'));
    }

    public function sendResetLinkEmail(Request $request)
    {
        $request->validate([
            'email' => 'required|email'
        ]);

        $forgot = User::where('email', $request->email)->where('active', 1)->first();
          
        if ($forgot !=""){
        //$gs = Setting::where('id', 1)->first();
        $token = "rst-".Str::random(40);

        $user = User::where('id', $forgot->id)->first();
        $user->token = $token;
        $user->reset_code = rand(100000, 999999);
        $user->save(); 
        
        $subject = 'Forgot Password';
        Mail::to($user->email)->send(new ResetLink($user, $subject));

    return response()->json([
                        'success' => 'A reset link has been sent to your email.'
                        //,'url' => route("user.password.reset", $courierInfo->id)
    ]);
        }else{
        // user not found
        return response()->json(['error' => 'No Account Found With This Email.']);    
        } 
    }

    public function mail()
    {
        return view('customer.mails.confirm_req');
    }

    public function showResetForm(Request $request, $token = null)
    {
        $title = 'Reset Password';
        //$settings = Setting::where('id', 1)->first();
        $reset = User::where('token', $token)->where('active', 1)->first();
        if($reset == null){
            return redirect()->route('user.login');  
        }else{
            return view('reset',compact('title','token',));
        }
    }

    public function reset(Request $request)
    { 
        $request->validate([
        'password' => 'required|string|min:6|',
        'cpassword' => 'same:password',
    ]);

        $user = User::where('token', $request->token)->where('active', 1)->first();
        $user->reset_code = NULL;
        $user->token = NULL;
        $user->password = bcrypt($request->password);
        //$user->setRememberToken("kvst-".Str::random(60));
        $result = $user->save();
        if($result){
            // $success = 'Password Updated successfully';
            // return response()->json([$login, $succes]);
            Auth::login($user);
            
            return response()->json(['success' => 'Password Updated successfully. Login using your new password']);
        }else{
         return response()->json(['error' => 'Password Update not successful, something went wrong']);
        }
    }
    
    public function verify($veri_token)
    {
        $gs = Setting::where('id', 1)->first();
        $settings = Setting::where('id', 1)->first();
         $token = User::where('verification_token', $veri_token)->first();
        if(!$token){
            $user = Auth::user();
            $user->verification_token = Str::random(40);
            $res = $user->save();
            if($res){
                Mail::to($user->email)->send(new WelcomeEmail($user));
                //new EmailVerificationNotification($user, false);
                return redirect()->back()->with('success', 'Verification link has been sent to you');
            }else{
                return redirect()->back()->with('success', 'Verification link was not sent');
            }
        }
            $user = User::where('verification_token', $veri_token)->first();
            $user->verification_token = null;
            $user->email_verified_at = Carbon::now();
            $user->access_status = 1;
            $user->active_status = 1;
            $result = $user->save();
            if ($result) {
                
                Mail::to($user->email)->send(new WelcomeEmail($user));
                return redirect()->route('user.login')->with('success',  'Verification Successful');
            }
    }

    public function logout(Request $request)
    {
        Auth::logout();
        if($request->session()->has('impersonated')){
        $secret_url =  session('secretUrl');
        $request->session()->forget('impersonated', 'secretUrl');
        // Flush permissions for impersonated user
        Cache::forget('permissions_' . session('impersonated'));

        $request->session()->invalidate();
        
        return $secret_url ? redirect()->to($secret_url)->with('success', 'secret logged out') :
            redirect()->route('user.dashboard');
        }else{
            $request->session()->invalidate();
            return redirect()->route('user.index')->with('success', '.logged out successfully');
        }
    }
}
