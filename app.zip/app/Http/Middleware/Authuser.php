<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

use Illuminate\Support\Facades\URL;
use Auth;

class Authuser
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        if(Auth::check()){
            return $next($request);
        }
        $href = URL::current();
       $trim = ltrim($href,"/user");
    //    var_dump($trim);
    //    return;
        return redirect(route('user.index').'?return='.$trim);
    }
}
