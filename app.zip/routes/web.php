<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::name('user.')->group(function () {
    Route::get('/', function () {
        return view('index');
    })->name('index');
    
    Route::post('/login', [AuthController::class, 'login'])->name('login.submit');
    
    Route::get('/register', function () {
        return view('register');
    })->name('register');

    Route::post('/register', [AuthController::class, 'register'])->name('register.submit');
    
    Route::get('/verify/{token?}', [AuthController::class, 'verify'])->name('verify');

    Route::get('/password/reset', function () {
        return view('forgot');
    })->name('password.request');
    
    //Route::get('/password/reset', [AuthController::class, 'showLinkRequestForm'])->name('password.request');
    //Route::get('/password/reset', [AuthController::class, 'showLinkRequestForm'])->name('password.request');
    Route::post('/password/email', [AuthController::class, 'sendResetLinkEmail'])->name('password.email');
    Route::get('/password/reset/{token}', [AuthController::class, 'showResetForm'])->name('password.reset');
    Route::post('/password/reset', [AuthController::class, 'reset'])->name('reset.submit');
    Route::get('/logout', [AuthController::class, 'logout'])->name('logout');

    
    Route::middleware(['authuser'])->prefix('user')->group(function () {
    Route::get('/barred', [DashboardController::class, 'blocked'])->name('blocked');
      
    Route::middleware(['barreduser'])->group(function () {
        Route::get('/', [DashboardController::class, 'dashboard'])->name('dashboard');
        Route::get('/dashboard', [DashboardController::class, 'dashboard'])->name('dashboard');
        Route::get('/profile', [DashboardController::class, 'profile'])->name('profile');
        Route::post('/profile', [DashboardController::class, 'updateprofile'])->name('update.profile');
        Route::post('/updateaccount', [UserDash::class, 'updateacct'])->name('updateacount');
        Route::post('/updateuserpass', [DashboardController::class, 'updateuserpass'])->name('updateuserpass');
        Route::post('/updateemail', [DashboardController::class, 'updateemail'])->name('updateemail');
        Route::post('/profilephoto', [DashboardController::class, 'avatar'])->name('update.profilephoto');
        
        Route::get('/uploadmusic', [DashboardController::class, 'uploadmusic'])->name('uploadmusic');
        Route::post('/uploadmusic', [DashboardController::class, 'musicsubmit'])->name('uploadmusic.submit');

        Route::get('/users', [UserController::class, 'users'])->name('users');
        Route::post('/adduser', [UserController::class, 'adduser'])->name('adduser');
        });
    });
});
