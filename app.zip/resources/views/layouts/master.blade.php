<!DOCTYPE html>
<html lang="{{str_replace('_', '-', app()->getLocale())}}">

<head>
    <title>Miraculous - Online Music Store Html Template</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Music">
    <meta name="keywords" content="">
    <meta name="author" content="kamleshyadav">
    <meta name="MobileOptimized" content="320">
    <!--Start Style -->
    <link rel="stylesheet" type="text/css" href="{{asset('css/fonts.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('css/bootstrap.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('css/font-awesome.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('js/plugins/swiper/css/swiper.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('js/plugins/nice_select/nice-select.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('js/plugins/player/volume.css')}}">
	<link rel="stylesheet" type="text/css" href="{{asset('js/plugins/scroll/jquery.mCustomScrollbar.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('css/style.css')}}">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert2/11.10.5/sweetalert2.min.css" />
	
    <script type="text/javascript" src="{{asset('js/jquery.js')}}"></script>{{--
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>--}}
	<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert2/11.10.5/sweetalert2.min.js"></script>
    <!-- Favicon Link -->
    <link rel="shortcut icon" type="image/png" href="{{asset('images/favicon.png')}}">
</head>

<body>
	<!----Loader Start---->
	<div class="ms_loader">
		<div class="wrap">
		  <img src="{{asset('images/loader.gif')}}" alt="" />
		</div>
	</div>
    <!----Main Wrapper Start---->
    <div class="ms_main_wrapper">

        <!---Side Menu Start--->
		
		@include('includes.sidebar')
		
		<!---Header--->
		
		@include('includes.header')
		
        <!---Banner--->
         <div class="ms-banner">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12">
                            <div class="ms_banner_img">
                                <img src="{{asset('images/banner.png')}}" alt="" class="img-fluid">
                            </div>
                            <div class="ms_banner_text">
                                <h1>This Month’s</h1>
                                <h1 class="ms_color">Record Breaking Albums !</h1>
                                <p>Dream your moments, Until I Met You, Gimme Some Courage, Dark Alley, One More Of A Stranger, Endless<br> Things, The Heartbeat Stops, Walking Promises, Desired Games and many more...</p>
                                <div class="ms_banner_btn">
                                    <a href="#" class="ms_btn">Listen Now</a>
                                    <a href="#" class="ms_btn">Add To Queue</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			<!---Main Content Start--->
	
	@yield('content')
	
        <!----Footer Start---->
		
		@include('includes.footer')
		
        <!----Audio Player Section---->
		
		@include('includes.audio_player')
		
	</div>
    <!----Register Modal Start---->
    <!-- Modal -->
    <div class="ms_register_popup">
        <div id="registermodal" class="modal centered-modal" role="dialog">
            <div class="modal-dialog register_dialog">
                <!-- Modal content-->
                <div class="modal-content">
                    <button type="button" class="close" data-dismiss="modal">
						<i class="fa_icon form_close"></i>
					</button>
                    <div class="modal-body">
                        <div class="ms_register_img">
                            <img src="images/register_img.png" alt="" class="img-fluid" />
                        </div>
                        <div class="ms_register_form">
                            <h2>Register / Sign Up</h2>
							<form id="register" action="{{route('user.register.submit')}}">
								<div class="form-group">
									<input type="text" id="regname" placeholder="Enter Your Name" class="form-control" required />
									<span class="form_icon"><i class="fa_icon form-user" aria-hidden="true"></i></span>
								</div>
								<div class="form-group">
									<input type="text" id="regusername" placeholder="Enter Your Username" class="form-control" required />
									<span class="form_icon"><i class="fa_icon form-user" aria-hidden="true"></i></span>
								</div>
								<div class="form-group">
									<input type="email" id="regemail" placeholder="Enter Your Email" class="form-control" required />
									<span class="form_icon"><i class="fa_icon form-envelope" aria-hidden="true"></i></span>
								</div>
								<div class="form-group">
									<input type="password" id="regpassword" placeholder="Enter Password" class="form-control" required />
									<span class="form_icon"><i class="fa_icon form-lock" aria-hidden="true"></i></span>
								</div>
								<div class="form-group">
									<input type="password" id="regcpassword" placeholder="Confirm Password" class="form-control" required />
									<span class="form_icon"><i class="fa_icon form-lock" aria-hidden="true"></i></span>
								</div>
									<button type="submit" id="regsubmitbtn" class="save_btn">register now</button>
							</form>
                            <p>Already Have An Account? <a href="#loginmodal" data-toggle="modal" class="ms_modal hideCurrentModel">login here</a></p>
                        </div>
                    </div>
                </div>
            </div>
<script>
$("#register").on('submit', function(){
    event.preventDefault()
	var Toast = Swal.mixin({
		toast: true,
		position: 'top-end',
		showConfirmButton: false,
		timer: 3000
	});
		var action = $(this).attr("action");
		var subbtn = $("#regsubmitbtn");

    $("#alert").hide()
    {{--<?php 
        if($terms->useterms =='yes'):
    ?>--}}
        //var tc = document.getElementById("agree");
        //var am = document.getElementById("accepting_marketing");
        //if(tc.checked){
        // var termc = 1;
       // }else{
       //  var termc = 0;
       // }
    {{--<?php else:?>
            //location.href = "{{route('user.dashboard')}}";
    <?php endif;?>--}}



        
        //if(am.checked){
        // var a_m = 1;
        //}else{
        // var a_m = 0;
        //}
    var formData = {
        {{--plan: $("#plan").val(),--}}
        name: $("#regname").val(),
        username: $("#regusername").val(),
        email: $("#regemail").val(),
        //phone: $("#regphone").val(),
        //dob: $("#dob").val(),
       // country: $("#country").val(),
        password: $("#regpassword").val(),
        cpassword: $("#regcpassword").val(),

        
    {{--<?php 
        if($terms->useterms =='yes'):
    ?>--}}
        //agree: termc,
    {{--<?php else:?>
            //location.href = "{{route('user.dashboard')}}";
    <?php endif;?>--}}
    
        //subscribe: a_m,
        _token: "{{csrf_token()}}",
    };
    $.ajax({
        type: 'POST',
        dataType:'JSON',
        url: action,
        data: formData,
        'beforeSend': function (){
        $(subbtn).attr("disabled",true);
        $(subbtn).html("<span class='spinner-border spinner-border-sm' role='status' aria-hidden='true'></span><span> Loading... </span>");
    },
    }).done(function (response) {
		
		if(response.status == 500){
			Toast.fire({
				icon: 'error',
				title: response.error
			})
		}else{
			Toast.fire({
			icon: 'success',
			title: response.success
		})
		setTimeout(function(){location.href="{{route('user.index')}}";}, 3000);
		}
}).fail(function(code, status) {
    Toast.fire({
            icon: 'danger',
            title: code.responseJSON.error
        })
}).always( function (xhr, status) {
        $(subbtn).attr("disabled",false);
        $(subbtn).html("Register")
});
});
</script>
        </div>
        <!----Login Popup Start---->
        <div id="loginmodal" class="modal centered-modal" role="dialog">
            <div class="modal-dialog login_dialog">
                <!-- Modal content-->
                <div class="modal-content">
                    <button type="button" class="close" data-dismiss="modal">
						<i class="fa_icon form_close"></i>
					</button>
                    <div class="modal-body">
                        <div class="ms_register_img">
                            <img src="images/register_img.png" alt="" class="img-fluid" />
                        </div>
                        <div class="ms_register_form">
                            <h2>login / Sign in</h2>
							<form id="login" action="{{route('user.login.submit')}}">
								<div class="form-group">
									<input type="email" id="logemail" placeholder="Enter Your Email" class="form-control" required />
									<span class="form_icon"><i class="fa_icon form-envelope" aria-hidden="true"></i></span>
								</div>
								<div class="form-group">
									<input type="password" id="logpassword" placeholder="Enter Password" class="form-control" required />
									<span class="form_icon"><i class="fa_icon form-lock" aria-hidden="true"></i></span>
								</div>
								<div class="remember_checkbox">
									<label>Keep me signed in
										<input type="checkbox">
										<span class="checkmark"></span>
									</label>
								</div>
								<div class="form-group">
									<button type="submit" id="logsubmitbtn" class="save_btn">login now</button>
								</div>
							</form>
                            <div class="popup_forgot">
                                <a href="#forgotmodal" data-toggle="modal" class="ms_modal1 hideCurrentModel">Forgot Password ?</a>
                            </div>
                            <p>Don't Have An Account? <a href="#registermodal" data-toggle="modal" class="ms_modal1 hideCurrentModel">register here</a></p>
                        </div>
                    </div>
                </div>
            </div>
<script>
$('#login').on('submit',function (){
	event.preventDefault();
	var Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000
    });
		var action = $(this).attr("action");
		var subbtn = $("#logsubmitbtn");

		// var rem = document.getElementById("remember");
		// 	if(rem.checked){
		// 	 var remb = 1;
		// 	}else{
		// 	 var remb = 0;
		// 	}
var formData = {
			email: $("#logemail").val(),
			//username: $("#logusername").val(),
			//phone: $("#logphone").val(),
			password: $("#logpassword").val(),
			//remember: remb,
			_token: "{{csrf_token()}}",
		};
		
		$.ajax({
			type: 'POST',
            dataType:'JSON',
            url: action,
			data: formData,
			'beforeSend': function (){
			$(subbtn).attr("disabled",true);
			$(subbtn).html("<span class='spinner-border spinner-border-sm' role='status' aria-hidden='true'></span><span> Loading... </span>");
			},
		}).done(function (response) {

            if(response.status == 500){
			Toast.fire({
				icon: 'error',
				title: response.error
			})
		}else{
            Toast.fire({
				icon: 'success',
				title: response.success
			})
			if(response.user.access == "1"){
			    <?php 
				if(isset($_GET['return'])):
				?>
				 location.href = "{{$_GET['return']}}";
				<?php else:?>
		          //location.href = "{{route('user.dashboard')}}";
				  setTimeout(function(){location.href="{{route('user.index')}}";}, 3000);
				 <?php endif;?>
			}else{
			location.href = "{{route('user.blocked')}}";	
			}
		}
	}).fail(function(code, status) {
		Toast.fire({
				icon: 'danger',
				title: code.responseJSON.error
			})
	}).always( function (xhr, status) {
            $(subbtn).attr("disabled",false);
            $(subbtn).html("Login")
	});
});
</script>
        </div>
        <!----Forgot Popup Start---->
        <div id="forgotmodal" class="modal centered-modal" role="dialog">
            <div class="modal-dialog login_dialog">
                <!-- Modal content-->
                <div class="modal-content">
                    <button type="button" class="close" data-dismiss="modal">
						<i class="fa_icon form_close"></i>
					</button>
                    <div class="modal-body">
                        <div class="ms_register_img">
                            <img src="images/register_img.png" alt="" class="img-fluid" />
                        </div>
                        <div class="ms_register_form">
                            <h2>Forgot Password</h2>
							<form id="forgot" action="">
								<div class="form-group">
									<input type="email" id="email" placeholder="Enter Your Email" class="form-control" required />
									<span class="form_icon"><i class="fa_icon form-envelope" aria-hidden="true"></i></span>
								</div>
								<div class="form-group">
									<button type="submit" class="ms_btn btn btn-round">Send Link</button>
								</div>
							</form>
                            <p>Remember my password ? <a href="#registermodal" data-toggle="modal" class="ms_modal1 hideCurrentModel">Login here</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!----Language Selection Modal---->
    <div class="ms_lang_popup">
        <div id="lang_modal" class="modal  centered-modal" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                    <button type="button" class="close" data-dismiss="modal">
						<i class="fa_icon form_close"></i>
					</button>
                    <div class="modal-body">
                        <h1>language selection</h1>
                        <p>Please select the language(s) of the music you listen to.</p>
                        <ul class="lang_list">
                            <li>
                                <label class="lang_check_label">
							English 
							<input type="checkbox" name="check"> 
							<span class="label-text"></span>
							</label>
                            </li>
                            <li>
                                <label class="lang_check_label">
							hindi
							<input type="checkbox" name="check"> 
							<span class="label-text"></span>
							</label>
                            </li>
                            <li>
                                <label class="lang_check_label">
							punjabi
							<input type="checkbox" name="check"> 
							<span class="label-text"></span>
							</label>
                            </li>
                            <li>
                                <label class="lang_check_label">
							French
							<input type="checkbox" name="check"> 
							<span class="label-text"></span>
							</label>
                            </li>
                            <li>
                                <label class="lang_check_label">
							 German 
							<input type="checkbox" name="check"> 
							<span class="label-text"></span>
							</label>
                            </li>
                            <li>
                                <label class="lang_check_label">
							Spanish
							<input type="checkbox" name="check"> 
							<span class="label-text"></span>
							</label>
                            </li>
                            <li>
                                <label class="lang_check_label">
							Chinese
							<input type="checkbox" name="check"> 
							<span class="label-text"></span>
							</label>
                            </li>
                            <li>
                                <label class="lang_check_label">
							Japanese 
							<input type="checkbox" name="check"> 
							<span class="label-text"></span>
							</label>
                            </li>
                            <li>
                                <label class="lang_check_label">
							Arabic
							<input type="checkbox" name="check"> 
							<span class="label-text"></span>
							</label>
                            </li>
                            <li>
                                <label class="lang_check_label">
							 Italian
							<input type="checkbox" name="check"> 
							<span class="label-text"></span>
							</label>
                            </li>
                        </ul>
                        <div class="ms_lang_btn">
                            <a href="#" class="ms_btn">apply</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
	<!----Queue Clear Model ---->
	<div class="ms_clear_modal">
		<div id="clear_modal" class="modal  centered-modal" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                    <button type="button" class="close" data-dismiss="modal">
						<i class="fa_icon form_close"></i>
					</button>
                    <div class="modal-body">
						<h1>Are you sure you want to clear your queue?</h1>
						<div class="clr_modal_btn">
							<a href="#">clear all</a>
							<a href="#">cancel</a>
						</div>
                    </div>
                </div>
            </div>
        </div>
	</div>
	<!----Queue Save Modal---->
	<div class="ms_save_modal">
		<div id="save_modal" class="modal  centered-modal" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                    <button type="button" class="close" data-dismiss="modal">
						<i class="fa_icon form_close"></i>
					</button>
                    <div class="modal-body">
						<h1>Log in to start sharing your music!</h1>
						<div class="save_modal_btn">
							<a href="#"><i class="fa fa-google-plus-square" aria-hidden="true"></i> continue with google </a>
							<a href="#"><i class="fa fa-facebook-square" aria-hidden="true"></i> continue with facebook</a>
						</div>
						<div class="ms_save_email">
							<h3>or use your email</h3>
							<div class="save_input_group">
								<input type="text" placeholder="Enter Your Name" class="form-control">
							</div>
							<div class="save_input_group">
                                <input type="password" placeholder="Enter Password" class="form-control">
                            </div>
							<button class="save_btn">Log in</button>
						</div>
						<div class="ms_dnt_have">
						    <span>Dont't have an account ?</span>
							<a href="javascript:;" class="hideCurrentModel" data-toggle="modal" data-target="#myModal">Register Now</a>
						</div>
                    </div>
                </div>
            </div>
        </div>
	</div>		
    <!--Main js file Style-->
    <script type="text/javascript" src="{{asset('js/bootstrap.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('js/plugins/swiper/js/swiper.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('js/plugins/player/jplayer.playlist.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('js/plugins/player/jquery.jplayer.min.js')}}"></script>{{--
    <script type="text/javascript" src="{{asset('js/plugins/player/audio-player.js')}}"></script>--}}
    <script type="text/javascript" src="{{asset('js/plugins/player/volume.js')}}"></script>
    <script type="text/javascript" src="{{asset('js/plugins/nice_select/jquery.nice-select.min.js')}}"></script>
	<script type="text/javascript" src="{{asset('js/plugins/scroll/jquery.mCustomScrollbar.js')}}"></script>
    <script type="text/javascript" src="{{asset('js/custom.js')}}"></script>
</body>
</html>