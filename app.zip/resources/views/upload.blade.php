@extends('layouts.master')
{{--@section('title', $title)--}}
@section('content')
            <!----Upload and Share Wrapper Start---->
            <div class="ms_upload_wrapper marger_top60">
                <div class="ms_upload_box">
                    <h2>Upload & Share Your Music With The World</h2>
                    <img src="{{asset('images/svg/upload.svg')}}" alt="">
                    <div class="ms_upload_btn">
                        <button type="button" id="openmusupload" class="ms_btn">Choose Music file</button>
						<input type="file" id="musicfile" style="display:none" />
                    </div>
                    <span> or </span>
                    <p>Drag And Drop Music Files</p>
                </div>
                <div class=" marger_top60">
                    <div class="ms_upload_box">
                        <div class="ms_heading">
                            <h1>Track Information</h1>
                        </div>
                        <div class="ms_pro_form">
							<form id="uploadmusicform" action="{{route('user.uploadmusic.submit')}}">
								<div class="form-group">
									<label>Track Name *</label>
									<input type="text" placeholder="Dream Your Moments" class="form-control" id="track" required />
								</div>
								<div class="form-group">
									<label>Select Artiste</label>
									<select class="form-control" id="artiste" required>
										<option value=""> -- Select -- </option>
									@foreach($artistes as $artiste)
										<option value="{{$artiste->id}}">{{$artiste->name}}</option>
									@endforeach
									</select>
								</div>
								<div class="form-group">
									<label>Select Album</label>
									<select class="form-control" id="album" required>
										<option value=""> -- Select -- </option>
									@foreach($albums as $album)
										<option value="{{$album->id}}">{{$album->title}}</option>
									@endforeach
									</select>
								</div>
								<div class="form-group">
									<label>Select Genre</label>
									<select class="form-control" id="genre" required>
										<option value=""> -- Select -- </option>
									@foreach($genres as $genre)
										<option value="{{$genre->id}}">{{$genre->name}}</option>
									@endforeach
									</select>
								</div>
								<div class="form-group">
									<label>Duration*</label>
									<input type="text" placeholder="Duration of the song" class="form-control" id="duration" required />
								</div>
								<div class="form-group">
									<label>Photo*</label>
									<input type="file" placeholder="Music Photo" class="form-control" id="musicphoto" required />
								</div>
								<div class="pro-form-btn text-center marger_top15">
									<div class="ms_upload_btn">
										<button type="submit" id="upmussubmitbtn" class="save_btn">Upload Now</button>
										<button type="reset" class="save_btn">cancel</button>
									</div>
								</div>
							</form>
                        </div>
                    </div>
                </div>
            </div>
            <!----Main div close---->
<script>				
	  $("#openmusupload").on('click', function(){
		 $("#musicfile").click(); 
	  });
	  
	  $("#uploadmusicform").on('submit', function(){
		event.preventDefault();
    var Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 3000
    });
	
		var action = $(this).attr("action");
		var subbtn = $("#upmussubmitbtn");
		
		  let musicphoto = $("#musicphoto")[0].files[0];
		  let musicfile = $("#musicfile")[0].files[0];
		  let track = $("#track").val();
		  let artiste = $("#artiste").val();
		  let album = $("#album").val();
		  let genre = $("#genre").val();
		  let duration = $("#duration").val();
		  
		  var formData = new FormData();
		  
		  formData.append("musicphoto", musicphoto);
		  formData.append("musicfile", musicfile);
		  formData.append("track", track);
		  formData.append("artiste", artiste);
		  formData.append("album", album);
		  formData.append("genre", genre);
		  formData.append("duration", duration);
		  formData.append("_token", "{{csrf_token()}}");
		  
		   $.ajax({
			type: 'POST',
            dataType:'JSON',
			cache: false,
			contentType: false,
			processData:false,
			url: action,
			data: formData,
			'beforeSend': function (){
			$(subbtn).attr("disabled",true);
			$(subbtn).html("<span class='spinner-border spinner-border-sm' role='status' aria-hidden='true'></span>Loading...");
			$('#alert').hide();
			},
		}).done(function (response) {
			Toast.fire({
				icon: 'success',
				title: response.success
			})
		         location.reload();
	}).fail(function(code, status) {
		Toast.fire({
				icon: 'danger',
				title: code.responseJSON.error
			})
	}).always( function (xhr, status) {
            $('#alert').show();
            $(subbtn).attr("disabled",false);
            $(subbtn).html("Upload Now")
	});   
	  });
	  </script>
@endsection